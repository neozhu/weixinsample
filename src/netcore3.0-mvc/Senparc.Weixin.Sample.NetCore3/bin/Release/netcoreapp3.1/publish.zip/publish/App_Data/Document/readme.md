﻿## Config.xml 文件说明

Config.xml 文件存放了系统配置、计数缓存参数等